package cs2321;

public @interface TimeComplexity {

}
