package cs2321;

import net.datastructures.*;

/*
 * Implement Graph interface. A graph can be declared as either directed or undirected.
 * In the case of an undirected graph, methods outgoingEdges and incomingEdges return the same collection,
 * and outDegree and inDegree return the same value.
 * 
 * @author CS2321 Instructor
 */
public class AdjacencyGraph<V, E> implements Graph<V, E> {

//nested classes for myVertex and myEdges
	private static class myVertex<V,E> implements Vertex<V> {
		private V element;
		private Position<Vertex<V>> pos;
		private Map<Vertex<V>, Edge<E>> outgoing, incoming;
		public myVertex(V elem, boolean graphIsDirected) {
			element = elem;
			outgoing = new HashMap<>();
			if(graphIsDirected) {
				incoming = new HashMap<>();
			}else {
				incoming = outgoing;
		}
	}

		@Override
		public V getElement() {
			
			return element;
		}
		
	
	public void setPosition(Position<Vertex<V>> p) {
		pos = p;
	}
	public Position<Vertex<V>> getPosition() {
		return pos;
	}
	public Map<Vertex<V>, Edge<E>> getOutgoing(){
		return outgoing;
	}
	public Map<Vertex<V>, Edge<E>> getIncoming(){
		return incoming;
	}
	}
	private static class myEdge<V,E> implements Edge<E> {
		private E element;
		private Position<Edge<E>> pos;
		private Vertex<V>[] endpoints;
		public myEdge(Vertex<V> u, Vertex<V> v, E elem) {
			element = elem;
			endpoints = (myVertex[]) new myVertex[2];
			endpoints[0] = u;
			endpoints[1] = v;
		}
		@Override
		public E getElement() {
		
			return element;
		}
		public Vertex<V>[] getEndpoints(){
			return endpoints;
		}
		public void SetPosition(Position<Edge<E>> p) {
			pos = p;
		}
		public Position<Edge<E>> getPosition(){
			return pos;
		}
	}
	public boolean isDirected;
	private DoublyLinkedList<Vertex<V>> vertices;
	private DoublyLinkedList<Edge<E>> edges;
	
	//the constructors
	public AdjacencyGraph(boolean directed) {
		isDirected = directed;
		vertices = new DoublyLinkedList<>();
		edges = new DoublyLinkedList<>();
		
	}

	public AdjacencyGraph() {
		vertices = new DoublyLinkedList<>();
		edges = new DoublyLinkedList<>();
	}
	private myEdge<V,E> validate(Edge<E> e){
		//validates function to check if e is an instance of the edges in adjacencymapgraph
		if(!(e instanceof Edge)) throw new IllegalArgumentException("Invalid edge");
		myEdge<V,E> edge = (myEdge<V,E>) e;
		return edge;
	}
	private myVertex<V, E> validate(Vertex<V> v){
		//validates function to check if v is an instance of the vertex in adjacencymapgraph
		if(!(v instanceof Vertex)) throw new IllegalArgumentException("Invalid vertex");
		myVertex<V,E> vertex = (myVertex<V,E>) v;
		return vertex;
	}


	/* (non-Javadoc)
	 * @see net.datastructures.Graph#edges()
	 */
	@TimeComplexity("O(1)")
	public Iterable<Edge<E>> edges() {
		// returns the iterable collection of the edges
		return edges;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#endVertices(net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	public Vertex[] endVertices(Edge<E> e) throws IllegalArgumentException {
		//gets endpoints of edge
		myEdge<V,E> edge = validate(e);
		return edge.getEndpoints();
	}


	/* (non-Javadoc)
	 * @see net.datastructures.Graph#insertEdge(net.datastructures.Vertex, net.datastructures.Vertex, java.lang.Object)
	 */
	@TimeComplexity("O(1)")
	@TimeComplexityExpected("O(1)")
	public Edge<E> insertEdge(Vertex<V> u, Vertex<V> v, E o) throws IllegalArgumentException {
		//inserts edge into edges dll, connecting to the matching vertices then return the new edge
		if(getEdge(u,v) == null) {
			myEdge<V,E> e = new myEdge<>(u,v, o);
			e.SetPosition(edges.addLast(e));
			myVertex<V,E> origin = validate(u);
			myVertex<V,E> destination = validate(v);
			origin.getOutgoing().put(v,e);
			destination.getIncoming().put(u, e);
			return e;
			
		}else throw new IllegalArgumentException("Edge from u to v exist");
		
		
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#insertVertex(java.lang.Object)
	 */
	@TimeComplexity("O(1)")
	public Vertex<V> insertVertex(V o) {
		//inserts vertex in DLL and sets its position
		myVertex<V,E> v = new myVertex<>(o,isDirected);
		v.setPosition(vertices.addLast(v));
		return v;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#numEdges()
	 */
	@TimeComplexity("O(1)")
	public int numEdges() {
		//return size of edges dll
		
		return edges.size();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#numVertices()
	 */
	@TimeComplexity("O(1)")
	public int numVertices() {
		//return size of vertices dll
		return  vertices.size();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#opposite(net.datastructures.Vertex, net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	public Vertex<V> opposite(Vertex<V> v, Edge<E> e) throws IllegalArgumentException {
		//finds the opposite vertex of an edge depending on which vertex was given returns the opposite endpoint
		myEdge<V,E> edge = validate(e);
		Vertex<V>[] endpoints = edge.getEndpoints();
		if(endpoints[0] == v) {
			return endpoints[1];
			
		}else if (endpoints[1]== v) {
			return endpoints[0];
		}
		else throw new IllegalArgumentException("v is not incident to this edge ");
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#removeEdge(net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	@TimeComplexityExpected("O(1)")
	public void removeEdge(Edge<E> e) throws IllegalArgumentException {
		//if e exists find endpoints and remove edge  from incoming/outgoing DLL setting its position to null
		myEdge<V,E> edge = validate(e);
		myVertex<V,E>[] endpoints = (myVertex<V,E>[]) edge.getEndpoints();
		endpoints[0].getOutgoing().remove(endpoints[1]);
		endpoints[1].getOutgoing().remove(endpoints[0]);
		edges.remove(edge.getPosition());
		edge.SetPosition(null);
		

	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#removeVertex(net.datastructures.Vertex)
	 */
	@TimeComplexity("O(deg(v))")
	public void removeVertex(Vertex<V> v) throws IllegalArgumentException {
		//if v exists iterate through incoming and outgoing edges remove them from DLL, remove  vertex set its position to null
		myVertex<V,E> vertex = validate(v);
		for(Edge<E> e : vertex.getOutgoing().values()) {
			removeEdge(e);
		}
		for(Edge<E> e : vertex.getIncoming().values()) {
			removeEdge(e);
		}
		vertices.remove(vertex.getPosition());
		vertex.setPosition(null);
		
	
	}

	/* 
     * replace the element in edge object, return the old element
     */
	@TimeComplexity("O(1)")
	public E replace(Edge<E> e, E o) throws IllegalArgumentException {
		myEdge<V,E> edge = validate(e);
		E oldE = edge.getElement();
		edge.element = o;
		return oldE;
	}

    /* 
     * replace the element in vertex object, return the old element
     */
	@TimeComplexity("O(1)")
	public V replace(Vertex<V> v, V o) throws IllegalArgumentException {
		myVertex<V,E> vertex = validate(v);
		V oldV = vertex.getElement();
		vertex.element = o;
		return oldV;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#vertices()
	 */
	@TimeComplexity("O(n)")
	public Iterable<Vertex<V>> vertices() {
		//return the collection of vertices
		
	
		return vertices;
	}
	@TimeComplexity("O(1)")
	@Override
	public int outDegree(Vertex<V> v) throws IllegalArgumentException {
		//return the number of edges where v is the destination 
		myVertex<V,E> vertex = validate(v);
		return vertex.getOutgoing().size();
	}
	@TimeComplexity("O(1)")
	@Override
	public int inDegree(Vertex<V> v) throws IllegalArgumentException {
		//return the number of edges where v is the destination 
		myVertex<V,E> vertex = validate(v);
		return vertex.getIncoming().size();
		
	}
	@TimeComplexity("O(deg(v))")
	@Override
	public Iterable<Edge<E>> outgoingEdges(Vertex<V> v)
			throws IllegalArgumentException {
		//returns itterable collection of outgoing edges
		myVertex<V,E> vertex = validate(v);
		return vertex.getOutgoing().values();
	}
		
	
	@TimeComplexity("O(deg(v))")
	@Override
	public Iterable<Edge<E>> incomingEdges(Vertex<V> v)
			throws IllegalArgumentException {
		////returns itterable collection of incoming edges
		myVertex<V,E> vertex = validate(v);
		return vertex.getIncoming().values();
	}
		
	@TimeComplexity("O(1)")
	@Override
	public Edge<E> getEdge(Vertex<V> u, Vertex<V> v)
			throws IllegalArgumentException {
		//returns edge if there is an edge to return
		myVertex<V,E> origin = validate(u);
		return origin.getOutgoing().get(v);
	}
	
}
