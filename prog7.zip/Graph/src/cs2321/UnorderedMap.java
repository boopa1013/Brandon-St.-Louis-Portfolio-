package cs2321;


import net.datastructures.Entry;
import net.datastructures.Map;
import net.datastructures.Position;

public class UnorderedMap<K,V> extends AbstractMap<K,V> {
	
	/* Use ArrayList or DoublyLinked list for the Underlying storage for the map of entries.
	 * TODO:  Uncomment one of these two lines;
	 * private ArrayList<mapEntry<K,V>> table; 
	 * private DoublyLinkedList<mapEntry<K,V>> table;
	 */
	private DoublyLinkedList<mapEntry<K,V>> table = new DoublyLinkedList<>();
	
	
	public UnorderedMap() {
		
	}
		

	@Override
	public int size() {
	return table.size();
		
	}

	@Override
	public boolean isEmpty() {
		
		return (table.size()==0);
	}
	@TimeComplexity("O(n)")
	@Override
	public V get(K key) {
		for(mapEntry<K,V> e : table) {
			if(e.getKey().equals(key)) {
				return e.getValue();
			}
		}
		return null;
	}
	@TimeComplexity("O(n)")
	@Override
	public V put(K key, V value) {
	for(mapEntry<K,V> e  : table) {
		if(e.getKey().equals(key)) {
			V oldValue = e.getValue();
			e.setValue(value);
			return oldValue;
		}
	}
		mapEntry<K,V> e = new mapEntry<K,V>(key, value);
		table.addLast(e);
		return null;
	}
	@TimeComplexity("O(n)")
	@Override
	public V remove(K key) {
		for(Position<mapEntry<K,V>> p : table.positions()) {
			mapEntry<K,V> e =p.getElement();
			if(e.getKey().equals(key)) {
				V oldValue = e.getValue();
				table.remove(p);
				return oldValue;
			}
		}
		return null;
	}


	@Override
	public Iterable<Entry<K, V>> entrySet() {
		DoublyLinkedList<Entry<K,V>> entrySet = new DoublyLinkedList<>();
		for(mapEntry<K,V> e : table) {
			entrySet.addLast(e);
		}
		return entrySet;
	}

}
