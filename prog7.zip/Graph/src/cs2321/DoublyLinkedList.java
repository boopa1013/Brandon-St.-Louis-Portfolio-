package cs2321;
import java.util.Iterator;
import net.datastructures.Position;
import net.datastructures.PositionalList;


public class DoublyLinkedList<E> implements PositionalList<E> {
	

	/* 
	 * Node class which should contain element and pointers to previous and next nodes
	 */
	public static class Node<E> implements Position<E> {
		private E element; 
		private  Node<E> prev;
		private Node<E> next;
		
		public Node(E e,Node<E> p, Node<E> n) {
			element = e;
			prev = p;
			next = n;
			}
		
		
		
		@Override
		public E getElement() throws IllegalStateException {
			if(next == null) throw new IllegalStateException(" Postion is no longer valid");
			return element;
		}
		public Node<E> getPrev(){
			return prev;
		}
		public Node<E> getNext(){
			return next;
		}
		public void  setElement(E e) {
			element = e;
		}
		public void  setPrev(Node<E> p) {
			prev = p;
		}
		public void  setNext(Node<E> n) {
			next = n;
		}
	}
	private Node<E>	head;
	private Node<E>	tail;
	private int size = 0;
	//doubly linked list instructor
	
		
	
	/*
	 *Element iterator will return one element at a time  
	 */
	private class ElementIterator implements Iterator<E> {
		Iterator<Position<E>> posIterator = new PositionIterator();
		//see's if theres a next element
		@Override
		public boolean hasNext() {
			return posIterator.hasNext();
		}
		//Returns next element
		@Override
		public E next() {
			return posIterator.next().getElement();
		}
		public void remove() {
			posIterator.remove();
		}
		
	}
	
	/*
	 * Position iterator will return one Position at a time  
	 */
	private class PositionIterator implements Iterator<Position<E>> {
		private Position<E> cursor = first();
		private Position<E> recent = null;
		@Override
		public boolean hasNext() {
			return (cursor != null);
		}

		@Override
		public Position<E> next() {
			recent = cursor;
			cursor = after(cursor);
			return recent;
		}
		public void remove() throws IllegalStateException{
			if( recent == null) throw new IllegalStateException("nothing to remove");
			DoublyLinkedList.this.remove(recent);
			recent = null;
		}
	}
	
	/*
	 * Position iterator will return one Position at a time  
	 */
	private class PositionIterable implements Iterable<Position<E>> {

		@Override
		public Iterator<Position<E>> iterator() {
			
			return new  PositionIterator();
		}
		
	}
	//validates p position 
	private Node<E> validate(Position<E> p) throws IllegalArgumentException{
		if(!(p instanceof Node)) throw new IllegalArgumentException("Invalid p");
		Node<E> node = (Node<E>) p;
	
		if(node.getNext() == null) throw new IllegalArgumentException("Cant remove nothing there");
		return node;
		}
	
	private Position<E> position(Node<E> node){
		if(node == head || node == tail) {
			return null;
		}
		return node;
	}

	public DoublyLinkedList() {
		head = new Node<>(null,null,null);
		tail = new Node<>(null,head,null);
		head.setNext(tail);
	}
    //returns size
	@Override
	public int size() {
		
		return size;
	}
	//checks if empty
	@Override
	public boolean isEmpty() {
		
		return (size == 0);
	}
	//gets first position in the linked list 
	@Override
	public Position<E> first() {
		
		return position(head.getNext());
	}
	//gets last position in the linked list 
	@Override
	public Position<E> last() {
		return position(tail.getPrev());
	}
	//position before 
	@Override
	public Position<E> before(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return position(node.getPrev());
	}
	
	//position after
	@Override
	public Position<E> after(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return position(node.getNext());
	}
	private Position<E> AddBetween(E e, Node<E> pred, Node<E> succ) {
		Node<E> newest = new Node<>(e, pred, succ);
		pred.setNext(newest);
		succ.setPrev(newest);
		size++;
		return newest;
	}
	
	
	//adds to front of list
	@Override
	public Position<E> addFirst(E e) {
		
		return AddBetween(e,head,head.getNext());
	}
	//adds to back of list
	@Override
	public Position<E> addLast(E e) {
		
		return AddBetween(e,tail.getPrev(),tail);
	}
	//add before element
	@Override
	public Position<E> addBefore(Position<E> p, E e)
			throws IllegalArgumentException {
		Node<E> node = validate(p);
		return AddBetween(e,node.getPrev(),node);
	
	}
	//add after element
	@Override
	public Position<E> addAfter(Position<E> p, E e)
			throws IllegalArgumentException {
		Node<E> node = validate(p);
		return AddBetween(e,node,node.getNext());
	
	}

	@Override
	public E set(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> node = validate(p);
		E answer = node.getElement();
		node.setElement(e);
		return answer;
	}
	//removes an element
	@Override
	public E remove(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		Node<E> predecessor = node.getPrev();
		Node<E> successor = node.getNext();
		predecessor.setNext(successor);
		successor.setPrev(predecessor);
		size--;
		E answer = node.getElement();
		node.setElement(null);
		node.setNext(null);
		node.setPrev(null);
		
		
		return answer;
	}

//removes first element
	public E removeFirst() throws IllegalArgumentException {
		Node<E> temp = head;
		temp = head.next;
		return temp.element;
	}
	//removes last element
	public E removeLast() throws IllegalArgumentException {
		Node<E> temp = tail;
		temp = tail.prev;
		return temp.element;
		
	}
	
	@Override
	public Iterator<E> iterator() {
		
		return new ElementIterator();
	}

	@Override
	public Iterable<Position<E>> positions() {
		
		return new PositionIterable();
	}

	@Override
	public Object [] toArray() {
		Object[] toArray = new Object[size];
		Node<E> temp = head;
		for(int i = 0; i< size; i++) {
			toArray[i] = (Object[]) temp.getElement();
			temp = temp.getNext();
		}
		return null;
	}


}
