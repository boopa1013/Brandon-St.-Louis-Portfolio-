package cs2321;

import java.util.Iterator;

import net.datastructures.List;

public class ArrayList<E> implements List<E> {
	
//make capacity variable declare it, to 16(default capacity) ,data array for elements with a capacity multiplier 
	public static final int Capacity = 16;
	private E[] data;
	private int size = 0;
	private int NewCapacity = Capacity;
	
	
	
	
	private class ArrayListIterator implements Iterator<E> {
		private  int t = 0;
		private boolean removable = false;
		//looks for another element in array  list
		
		@Override
		public boolean hasNext() {
			
			return (t < size);
		}

		@Override
		public E next() {
			removable = true;
			return data[t++];
		}
		//sees if element is removable
		public void remove() throws IllegalStateException {
			if (!removable) throw new IllegalStateException("can't be removed");
			ArrayList.this.remove(t-1);
			t--;
			removable = false;
		}
		
	}
	//creates an array list with the set capacity 
	public ArrayList() {
		// Default capacity: 16
	this(Capacity);
	}
	// create an array list with the specified capacity
	public ArrayList(int capacity) {
		data = (E[])new Object[capacity];
		
	}
	//return the size
	
	@Override
	public int size() {
		
		return size;
	}

	// Return the current capacity of array, not the number of elements.
	// Notes: The initial capacity is 16. When the array is full, the array should be doubled. 
	public int capacity() {
		
		return (NewCapacity);
	}
	
	//if arraylist empty returns
	@Override
	public boolean isEmpty() {
		
		return (size == 0);
	}
	//gets element at position i in the arraylist
	@Override
	public E get(int i) throws IndexOutOfBoundsException {
		checkIndex(i, size);
		return data[i];
	}


	@Override
	public E set(int i, E e) throws IndexOutOfBoundsException {
		checkIndex(i, size);
		E temp = data[i];
		data[i] = e;
		return temp;
	}
	//adds elements in array list at postion i
	@Override
	public void add(int i, E e) throws IndexOutOfBoundsException {
		checkIndex(i, size+1);
		if (size == data.length) {
			NewCapacity = 2 * data.length ;
			resize(NewCapacity);
			}
		for(int j = size - 1; j >= i; j--) {
			data[j+1] = data[j];
		}
		data[i] = e;
		size++;
		
	}
	//removes elements in array list at postion i
	@Override
	public E remove(int i) throws IndexOutOfBoundsException {
		checkIndex(i, size);
		E temp = data[i];
		for(int j = i; j < size-1; j++) {
			data[j] = data[j+1];
		}
		data[size - 1] = null;
		size--;
		return temp;
	}

//add element to the front of the array list
	public void addFirst(E e)  {
		add(0, e);
	}
	//add element to the end of the array list
	public void addLast(E e)  {
		add(size, e);
	}
	//removes first element of the array list 
	public E removeFirst() throws IndexOutOfBoundsException {
		
		return remove(0);
	}
	//removes last element of the array list 
	public E removeLast() throws IndexOutOfBoundsException {
		
		
		return remove(size - 1 );
	}
	//resizes array double capacity when full
	protected void resize(int capacity) {
		E[] temp = (E[]) new Object[capacity];
		for(int j = 0; j < size; j++) {
			temp[j] = data[j];
		}
		data = temp;
	}
	//check if i is in the index j
	protected void checkIndex(int i, int j) throws IndexOutOfBoundsException {
		if(i < 0 || i >= j) {
			throw new IndexOutOfBoundsException(" Illegal index: " + i);
			
		}
	}
	public E[] toArray() {
		return data;
	}

	
	@Override
	public Iterator<E> iterator() {
		return new ArrayListIterator();
	}

	

}
